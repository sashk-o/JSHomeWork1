document.write("Завдання 3:<br/><br/>");

let h = prompt("Введіть висоту циліндра ", "0");
let r = prompt("Введіть радіус циліндра ", "0");

let height = parseFloat(h);
let radius = parseFloat(r);

let square = 2*Math.PI*radius*height;
let volume = Math.PI*Math.pow(radius, 2)*height;

document.write("Висота циліндра - " + height+ "<br/>");
document.write("Радіус циліндра - " + radius+ "<br/><br/>");

document.write("Площа циліндра дорівнює - " + square.toFixed(3) + " см^2" + "<br/>");
document.write("Об'єм циліндра дорівнює - " + volume.toFixed(3) + " см^3" + "<br/>");