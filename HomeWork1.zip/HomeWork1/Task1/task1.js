document.write("Завдання 1:<br/><br/>");

let x = 6;
let y = 15;
let z = 4;

document.write("x = " + x + "<br/>");
document.write("y = " + y + "<br/>");
document.write("z = " + z + "<br/><br/>");

let res1 = x+y-x++*z;
document.write("res1 = " + res1 + "<br/>");
let res2 = y-x++ *z;
document.write("res2 = " + res2 + "<br/>");
let res3 = x+5%z;
document.write("res3 = " + res3 + "<br/>");
let res4 = x++ +y*5;
document.write("res4 = " + res4 + "<br/>");
let res5 = y-x++ *z;
document.write("res5 = " + res5 + "<br/>");