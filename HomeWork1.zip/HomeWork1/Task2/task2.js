document.write("Завдання 2:<br/><br/>");

let a = 10;
let b = 15;
let c = 9;

document.write("Перше число - " + a + "<br/>");
document.write("Друге число - " + b + "<br/>");
document.write("Третє число - " + c + "<br/><br/>");

let aver = (a+b+c)/3;
document.write("Середнє арифметичне трьох чисел - " + aver.toFixed(2) + "<br/>");